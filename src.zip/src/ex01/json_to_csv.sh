#!/bin/sh

jq -f filter.jq ../ex00/hh.json > hh.csv
